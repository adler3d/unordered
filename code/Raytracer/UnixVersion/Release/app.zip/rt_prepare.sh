echo " "
echo "run node with this filename "
cat rt_proc_log_fn.txt
echo " "
echo "or just read content of rt_proc_log_fn.txt in node js and use it as file name"
echo "in case when we need do something on nodejs side with that"
echo "PS: this message writen inside rt_prepare.sh"
echo "under_construction"

